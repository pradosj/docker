define( "JBrowse/View/Track/Wiggle", [
            'JBrowse/View/Track/Wiggle/XYPlot'
        ],
        function( xyplot ) {
return xyplot;
});
