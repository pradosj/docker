define( "JBrowse/Store/BigWig", ['JBrowse/Store/SeqFeature/BigWig'], function( bw ){
  return bw;
});
